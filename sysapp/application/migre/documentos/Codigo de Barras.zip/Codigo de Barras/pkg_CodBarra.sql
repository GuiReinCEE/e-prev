Create Or Replace Package Utility_Pkg As

Function F_monta_caracteres_I25
   (valores	in	varchar2)
   return varchar2;
Pragma Restrict_References(F_monta_caracteres_I25, WNDS, WNPS, RNPS);

End Utility_Pkg  ;
/

Create Or Replace Package Body Utility_Pkg As

Function F_monta_caracteres_I25
     (valores	in	varchar2)
     return varchar2
is
  i		number;
  sValores      varchar2(200);
  achei		boolean := false;
  resultado	varchar2(1000);
  parte 	varchar2(2);
begin

  if (length(valores) mod 2) = 0 then
     sValores := valores;
  else
     sValores := '0' || valores;
  end if;
  i := 1;
  resultado := '<';
  while not achei loop
    
     parte := substr(sValores,i,2);
     if parte = '00' then
        resultado := resultado || 'nnWWn';
     elsif parte = '01' then
        resultado := resultado || 'NnwwN';
     elsif parte = '02' then
        resultado := resultado || 'nNwwN';
     elsif parte = '03' then
        resultado := resultado || 'NNwwn';
     elsif parte = '04' then
        resultado := resultado || 'nnWwN';
     elsif parte = '05' then
        resultado := resultado || 'NnWwn';
     elsif parte = '06' then
        resultado := resultado || 'nNWwn';
     elsif parte = '07' then
        resultado := resultado || 'nnwWN';
     elsif parte = '08' then
        resultado := resultado || 'NnwWn';
     elsif parte = '09' then
        resultado := resultado || 'nNwWn';
     elsif parte = '10' then
        resultado := resultado || 'wnNNw';
     elsif parte = '11' then
        resultado := resultado || 'WnnnW';
     elsif parte = '12' then
        resultado := resultado || 'wNnnW';
     elsif parte = '13' then
        resultado := resultado || 'WNnnw';
     elsif parte = '14' then
        resultado := resultado || 'wnNnW';
     elsif parte = '15' then
        resultado := resultado || 'WnNnw';
     elsif parte = '16' then
        resultado := resultado || 'wNNnw';
     elsif parte = '17' then
        resultado := resultado || 'wnnNW';
     elsif parte = '18' then
        resultado := resultado || 'WnnNw';
     elsif parte = '19' then
        resultado := resultado || 'wNnNw';
     elsif parte = '20' then
        resultado := resultado || 'nwNNw';
     elsif parte = '21' then
        resultado := resultado || 'NwnnW';
     elsif parte = '22' then
        resultado := resultado || 'nWnnW';
     elsif parte = '23' then
        resultado := resultado || 'NWnnw';
     elsif parte = '24' then
        resultado := resultado || 'nwNnW';
     elsif parte = '25' then
        resultado := resultado || 'NwNnw';
     elsif parte = '26' then
        resultado := resultado || 'nWNnw';
     elsif parte = '27' then
        resultado := resultado || 'nwnNW';
     elsif parte = '28' then
        resultado := resultado || 'NwnNw';
     elsif parte = '29' then
        resultado := resultado || 'nWnNw';
     elsif parte = '30' then
        resultado := resultado || 'wwNNn';
     elsif parte = '31' then
        resultado := resultado || 'WwnnN';
     elsif parte = '32' then
        resultado := resultado || 'wWnnN';
     elsif parte = '33' then
        resultado := resultado || 'WWnnn';
     elsif parte = '34' then
        resultado := resultado || 'wwNnN';
     elsif parte = '35' then
        resultado := resultado || 'WwNnn';
     elsif parte = '36' then
        resultado := resultado || 'wWNnn';
     elsif parte = '37' then
        resultado := resultado || 'wwnNN';
     elsif parte = '38' then
        resultado := resultado || 'WwnNn';
     elsif parte = '39' then
        resultado := resultado || 'wWnNn';
     elsif parte = '40' then
        resultado := resultado || 'nnWNw';
     elsif parte = '41' then
        resultado := resultado || 'NnwnW';
     elsif parte = '42' then
        resultado := resultado || 'nNwnW';
     elsif parte = '43' then
        resultado := resultado || 'NNwnw';
     elsif parte = '44' then
        resultado := resultado || 'nnWnW';
     elsif parte = '45' then
        resultado := resultado || 'NnWnw';
     elsif parte = '46' then
        resultado := resultado || 'nNWnw';
     elsif parte = '47' then
        resultado := resultado || 'nnwNW';
     elsif parte = '48' then
        resultado := resultado || 'NnwNw';
     elsif parte = '49' then
        resultado := resultado || 'nNwNw';
     elsif parte = '50' then
        resultado := resultado || 'wnWNn';
     elsif parte = '51' then
        resultado := resultado || 'WnwnN';
     elsif parte = '52' then
        resultado := resultado || 'wNwnN';
     elsif parte = '53' then
        resultado := resultado || 'WNwnn';
     elsif parte = '54' then
        resultado := resultado || 'wnWnN';
     elsif parte = '55' then
        resultado := resultado || 'WnWnn';
     elsif parte = '56' then
        resultado := resultado || 'wNWnn';
     elsif parte = '57' then
        resultado := resultado || 'wnwNN';
     elsif parte = '58' then
        resultado := resultado || 'WnwNn';
     elsif parte = '59' then
        resultado := resultado || 'wNwNn';
     elsif parte = '60' then
        resultado := resultado || 'nwWNn';
     elsif parte = '61' then
        resultado := resultado || 'NwwnN';
     elsif parte = '62' then
        resultado := resultado || 'nWwnN';
     elsif parte = '63' then
        resultado := resultado || 'NWwnn';
     elsif parte = '64' then
        resultado := resultado || 'nwWnN';
     elsif parte = '65' then
        resultado := resultado || 'NwWnn';
     elsif parte = '66' then
        resultado := resultado || 'nWWnn';
     elsif parte = '67' then
        resultado := resultado || 'nwwNN';
     elsif parte = '68' then
        resultado := resultado || 'NwwNn';
     elsif parte = '69' then
        resultado := resultado || 'nWwNn';
     elsif parte = '70' then
        resultado := resultado || 'nnNWw';
     elsif parte = '71' then
        resultado := resultado || 'NnnwW';
     elsif parte = '72' then
        resultado := resultado || 'nNnwW';
     elsif parte = '73' then
        resultado := resultado || 'NNnww';
     elsif parte = '74' then
        resultado := resultado || 'nnNwW';
     elsif parte = '75' then
        resultado := resultado || 'NnNww';
     elsif parte = '76' then
        resultado := resultado || 'nNNww';
     elsif parte = '77' then
        resultado := resultado || 'nnnWW';
     elsif parte = '78' then
        resultado := resultado || 'NnnWw';
     elsif parte = '79' then
        resultado := resultado || 'nNnWw';
     elsif parte = '80' then
        resultado := resultado || 'wnNWn';
     elsif parte = '81' then
        resultado := resultado || 'WnnwN';
     elsif parte = '82' then
        resultado := resultado || 'wNnwN';
     elsif parte = '83' then
        resultado := resultado || 'WNnwn';
     elsif parte = '84' then
        resultado := resultado || 'wnNwN';
     elsif parte = '85' then
        resultado := resultado || 'WnNwn';
     elsif parte = '86' then
        resultado := resultado || 'wNNwn';
     elsif parte = '87' then
        resultado := resultado || 'wnnWN';
     elsif parte = '88' then
        resultado := resultado || 'WnnWn';
     elsif parte = '89' then
        resultado := resultado || 'wNnWn';
     elsif parte = '90' then
        resultado := resultado || 'nwNWn';
     elsif parte = '91' then
        resultado := resultado || 'NwnwN';
     elsif parte = '92' then
        resultado := resultado || 'nWnwN';
     elsif parte = '93' then
        resultado := resultado || 'NWnwn';
     elsif parte = '94' then
        resultado := resultado || 'nwNwN';
     elsif parte = '95' then
        resultado := resultado || 'NwNwn';
     elsif parte = '96' then
        resultado := resultado || 'nWNwn';
     elsif parte = '97' then
        resultado := resultado || 'nwnWN';
     elsif parte = '98' then
        resultado := resultado || 'NwnWn';
     elsif parte = '99' then
        resultado := resultado || 'nWnWn';
     End if;

     if i < length(valores) then
        i := i + 2;
     else
        achei := true;
     end if;

  end loop;

  resultado := resultado || '>';
  return(resultado); 

end F_monta_caracteres_I25;

-- *******************************************************

End Utility_Pkg;
/
Show Errors
